package com.example.ContentManagement;

import org.springframework.data.jpa.repository.JpaRepository;

public interface conRepository extends JpaRepository<ConMngmnt,Long> {

}
