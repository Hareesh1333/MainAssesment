package com.example.ContentManagement;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class ConMngmnt {

    private long id;
    private String screen;
    private String Description;

        protected ConMngmnt(){}

    public ConMngmnt(long id, String screen, String description) {
        this.id = id;
        this.screen = screen;
        Description = description;
    }
@Id
@GeneratedValue
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getScreen() {
        return screen;
    }

    public void setScreen(String screen) {
        this.screen = screen;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }
}
