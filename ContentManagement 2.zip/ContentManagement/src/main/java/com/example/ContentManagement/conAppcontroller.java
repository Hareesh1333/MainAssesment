package com.example.ContentManagement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class conAppcontroller {
@Autowired
    private conService service;
@RequestMapping("/")
public String viewhomepage(Model model){
    List<ConMngmnt> listConMngmnts= service.listAll();
    model.addAttribute("listConMngmnts",listConMngmnts);
    return "index";
}

@RequestMapping("/create")
    public String shownewscreenpage(Model model){
    ConMngmnt conMngmnt = new ConMngmnt();
    model.addAttribute("ConMngmnt",conMngmnt);
    return "create";
}

@RequestMapping("/edit")
    public ModelAndView showeditscreenpage(@PathVariable(name = "id") int id){
    ModelAndView mov = new ModelAndView("Edit");
    ConMngmnt conMngmnt = service.get(id);
    mov.addObject("ConMngmnt",conMngmnt);
    return mov;}

    @RequestMapping("/delete/{id}")
    public String deleteScreen(@PathVariable(name="id")int id){
    service.delete(id);
    return "redirect:/";
    }


}
