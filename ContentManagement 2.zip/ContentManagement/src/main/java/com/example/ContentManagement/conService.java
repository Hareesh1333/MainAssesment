package com.example.ContentManagement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class conService {
    @Autowired
    private conRepository hari;
    public List<ConMngmnt>listAll(){return hari.findAll();}
    public void save (ConMngmnt conMngmnt){hari.save(conMngmnt);}
    public ConMngmnt get(long id){return hari.findById(id).get();}
    public void delete (long id){hari.deleteById(id);}

}
